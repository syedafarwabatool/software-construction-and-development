package com.flavor.fiesta.flavor.fiesta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlavorFiestaApplicationTests {

	@Test
	void contextLoads() {
	}

}
