package com.flavor.fiesta.flavor.fiesta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlavorFiestaApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlavorFiestaApplication.class, args);
	}

}
